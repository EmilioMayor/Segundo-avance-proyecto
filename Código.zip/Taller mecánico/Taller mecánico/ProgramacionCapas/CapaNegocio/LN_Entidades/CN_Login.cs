﻿using CapaDatos.ConexionDB;
using CapaDatos.Interface;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos.ExecuteSQL;

namespace CapaNegocio.LN_Entidades
{
    public class CN_Login
    {
        private Interface_Negocio objIntLogin = new Interface_Negocio();
        int id;
        string nombre_usuario;
        string contraseña;

        public CN_Login()
        {
            int id = 0;
            string nombre_usuario = string.Empty;
            string contraseña = string.Empty;
        }

        public CN_Login(int id, string nombre_usuario, string contraseña)
        {
            this.id = id;
            this.nombre_usuario = nombre_usuario;
            this.contraseña = contraseña;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombre_usuario
        {
            get { return nombre_usuario; }
            set { nombre_usuario = value; }
        }

        public string Contraseña
        {
            get { return contraseña; }
            set { contraseña = value; }
        }

               
        public DataTable getListadoUsuarios()
        {
            try
            {
                return objIntLogin.getListaUsuarios();
            }
            catch (Exception e)
            {
                throw new Exception("Error al obtener listado de usuarios -> " + e.Message);
            }
        }

        public bool ValidarCredenciales()
        {
            try
            {
                DataTable tb_Login = getListadoUsuarios();

                DataRow[] filas = tb_Login.Select($"nombre_usuario = '{nombre_usuario}' AND contraseña = '{contraseña}'");

                return filas.Length > 0;
            }
            catch (Exception e)
            {
                throw new Exception("Error al validar credenciales -> " + e.Message);
            }
        }

        public bool GuardarUsuario(CN_Login login)
        {

            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@nombre_usuario", login.nombre_usuario, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@contraseña", login.contraseña, SqlDbType.Text));


                return objIntLogin.CrearUsuario(lista);

            }
            catch (Exception e)
            {
                throw new Exception("Error al Guardar Datos de Usuario -> " + e.Message);
            }

        }

        public bool ActualizarUsuario(CN_Login login)
        {

            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@id", login.Id, SqlDbType.Int));
                lista.Add(new CD_Parameter_SP("@nombre_usuario", login.nombre_usuario, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@contraseña", login.contraseña, SqlDbType.Text));


                return objIntLogin.ActualizarUsuario(lista);

            }
            catch (Exception e)
            {
                throw new Exception("Error al Actualizar Datos de Usuario -> " + e.Message);
            }

        }
        public bool EliminarUsuario(CN_Login login)
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@IdNombre_usuario", login.Id, SqlDbType.Int));

                return objIntLogin.EliminarUsuario(lista);
            }
            catch (Exception e)
            {
                throw new Exception("Error al Eliminar Datos de Usuario -> " + e.Message);
            }
        }




    }
}



