﻿using CapaDatos.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.LN_Entidades
{
    public class CN_Repuesto
    {
        private Interface_Negocio objIntRepuesto = new Interface_Negocio();
        int id;
        string nombre;
        int cantidad;
        float precio;
        float total;

        public CN_Repuesto()
        {
            id = 0;
            nombre = string.Empty; 
            cantidad = 0;
            precio = 0;
            total = 0;
        }

        CN_Repuesto(int id, string nombre, int cantidad, float precio, float total)
        {
            this.id = id;
            this.nombre = nombre;
            this.cantidad = cantidad;
            this.precio = precio;
            this.total = total;
        }

        public int Id 
        { 
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public int Cantidad
        { 
            get { return cantidad; } 
            set { cantidad = value; } 
        }

        public float Precio
        {
            get { return precio; }
            set { precio = value; }
        }

        public float Total
        { 
            get { return total; } 
            set {  total = value; } 
        }       
    }
}
