﻿using CapaDatos.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.LN_Entidades
{
    public class CN_ServiciosAdicionales
    {
        private Interface_Negocio objIntServiciosAdicionales = new Interface_Negocio();
        private int id;
        /*string alineacion;
        string cambio_aceite ;
        string cambio_bateria;
        string lavado;
        string reemplazo_luces;*/
        string nombre;
        int total;
        


        public CN_ServiciosAdicionales()
        {
            id = 0;
            nombre = string.Empty;
            total = 0;
        }


        public CN_ServiciosAdicionales(int id, string nombre, int total)
        {
            this.id = id;
            this.nombre = nombre;
            this.total = total;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public int Total
        {
            get { return total; }
            set { total = value; }
        }


        public DataTable getListadoServiciosAdicionales()
        {
            try
            {
                return objIntServiciosAdicionales.getListaServiciosAdicionales();
            }
            catch (Exception e)
            {
                throw new Exception("Error al obtener listado de servicios adicionales -> " + e.Message);
            }
        }

        public bool GuardarServiciosAdicionales(CN_ServiciosAdicionales serviciosAdicionales)
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@nombre", serviciosAdicionales.Nombre, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@total", serviciosAdicionales.Total, SqlDbType.BigInt));

                return objIntServiciosAdicionales.CreaServiciosAdicionales(lista);
            }
            catch (Exception e)
            {
                throw new Exception("Error al Guardar Datos de Servicios Adicionales -> " + e.Message);
            }

        }

        public bool ActualizarServiciosAdicionales(CN_ServiciosAdicionales serviciosAdicionales)
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@id", serviciosAdicionales.Id, SqlDbType.Int));
                lista.Add(new CD_Parameter_SP("@nombre", serviciosAdicionales.Nombre, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@total", serviciosAdicionales.Total, SqlDbType.BigInt));

                return objIntServiciosAdicionales.ActualizarServiciosAdicionales(lista);

            }
            catch (Exception e)
            {
                throw new Exception("Error al Actualizar Datos de Servicios Adicionales -> " + e.Message);
            }

        }
        public bool EliminarServiciosAdicionales(CN_ServiciosAdicionales serviciosAdicionales)
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@IdServicio", serviciosAdicionales.Id, SqlDbType.Int));

                return objIntServiciosAdicionales.EliminaServiciosAdicionales(lista);
            }
            catch (Exception e)
            {
                throw new Exception("Error al Eliminar Datos de Servicios -> " + e.Message);
            }
        }
    }
}
