﻿using CapaNegocio.LN_Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmMecanico : Form
    {
        CN_Mecanico obj_cn_mecanico = new CN_Mecanico();
        private bool is_nuevo = false;

        public frmMecanico()
        {
            InitializeComponent();
        }

        private void frmMecanico_Load(object sender, EventArgs e)
        {
            LoadDgvMecanico();
        }

        private void setearControles()
        {
            txtId.Text = string.Empty;
            txtNombres.Text = string.Empty;
            txtApellidos.Text = string.Empty;
            txtCedula.Text = string.Empty;
            txtCelular.Text = string.Empty;
            txtCorreo.Text = string.Empty;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            is_nuevo = true;
            setearControles();
            btnGrabar.Enabled = true;
            btnEliminar.Enabled = false;
            btnNuevo.Enabled = false;
        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            try
            {
                if (is_nuevo)
                {
                    obj_cn_mecanico.Nombres = txtNombres.Text;
                    obj_cn_mecanico.Apellidos = txtApellidos.Text;
                    obj_cn_mecanico.Cedula = txtCedula.Text;
                    obj_cn_mecanico.Celular = Convert.ToInt32(txtCelular.Text);
                    obj_cn_mecanico.Correo = txtCorreo.Text;
                    if (obj_cn_mecanico.GuardarMecanico(obj_cn_mecanico))
                        MessageBox.Show("Registro Guardado");
                    else
                        MessageBox.Show("Registro No pudo Grabarse");

                    LoadDgvMecanico();
                    btnGrabar.Enabled = false;
                    btnNuevo.Enabled = true;
                    is_nuevo = false;
                }
                else
                {
                    obj_cn_mecanico.Id = Convert.ToInt16(txtId.Text);
                    obj_cn_mecanico.Nombres = txtNombres.Text;
                    obj_cn_mecanico.Apellidos = txtApellidos.Text;
                    obj_cn_mecanico.Cedula = txtCedula.Text;
                    obj_cn_mecanico.Celular = Convert.ToInt32(txtCelular.Text);
                    obj_cn_mecanico.Correo = txtCorreo.Text;
                    if (obj_cn_mecanico.ActualizarMecanico(obj_cn_mecanico))
                    {
                        MessageBox.Show("Registro Actualizado con Exito");
                        LoadDgvMecanico();
                    }
                    else
                        MessageBox.Show("Registro NO pudo ser Actualizado");
                    btnGrabar.Enabled = false;
                    btnEliminar.Enabled = false;
                    btnNuevo.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadDgvMecanico()
        {
            try
            {
                dgvClienteVehiculo.DataSource = obj_cn_mecanico.getListadoMecanico();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvClienteVehiculo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var fila = e.RowIndex;
            if (fila > 0)
            {
                txtId.Text = dgvClienteVehiculo.Rows[fila].Cells["ID"].Value.ToString();
                txtNombres.Text = dgvClienteVehiculo.Rows[fila].Cells["NOMBRES"].Value.ToString();
                txtApellidos.Text = dgvClienteVehiculo.Rows[fila].Cells["APELLIDOS"].Value.ToString();
                txtCedula.Text = dgvClienteVehiculo.Rows[fila].Cells["CEDULA"].Value.ToString();
                txtCelular.Text = dgvClienteVehiculo.Rows[fila].Cells["CELULAR"].Value.ToString();
                txtCorreo.Text = dgvClienteVehiculo.Rows[fila].Cells["CORREO"].Value.ToString();

                btnNuevo.Enabled = false;
                btnGrabar.Enabled = true;
                btnEliminar.Enabled = true;
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                obj_cn_mecanico.Id = Convert.ToInt16(txtId.Text);
                if (obj_cn_mecanico.EliminarMecanico(obj_cn_mecanico))
                {
                    MessageBox.Show("Registro Eliminado con Exito");
                    LoadDgvMecanico();
                }
                else
                    MessageBox.Show("No se Pudo Eliminar el Registro");
                btnGrabar.Enabled = false;
                btnEliminar.Enabled = false;
                btnNuevo.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
