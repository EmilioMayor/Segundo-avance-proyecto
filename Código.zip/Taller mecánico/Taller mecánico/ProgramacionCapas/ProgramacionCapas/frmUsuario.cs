﻿using CapaNegocio.LN_Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmUsuario : Form
    {
        CN_Login obj_cn_login = new CN_Login();
        private bool is_nuevo = false;
        public frmUsuario()
        {
            InitializeComponent();
        }
        private void setearControles()
        {
            txtId.Text = string.Empty;
            txtUsuario.Text = string.Empty;
            txtContraseña.Text = string.Empty;
        }
        private void btnNuevo_Click(object sender, EventArgs e)
        {
            is_nuevo = true;
            setearControles();
            btnGrabar.Enabled = true;
            btnEliminar.Enabled = false;
            btnNuevo.Enabled = false;
        }

        private void LoadDgvUsuario()
        {
            try
            {
                dgvUsuarios.DataSource = obj_cn_login.getListadoUsuarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            try
            {
                if (is_nuevo)
                {
                    obj_cn_login.Nombre_usuario = txtUsuario.Text;
                    obj_cn_login.Contraseña = txtContraseña.Text;

                    if (obj_cn_login.GuardarUsuario(obj_cn_login))
                        MessageBox.Show("Registro Guardado");
                    else
                        MessageBox.Show("Registro No pudo Grabarse");

                    LoadDgvUsuario();
                    btnGrabar.Enabled = false;
                    btnNuevo.Enabled = true;
                    is_nuevo = false;
                }
                else
                {
                    obj_cn_login.Id = Convert.ToInt16(txtId.Text);
                    obj_cn_login.Nombre_usuario = txtUsuario.Text;
                    obj_cn_login.Contraseña = txtContraseña.Text;

                    if (obj_cn_login.ActualizarUsuario(obj_cn_login))
                    {
                        MessageBox.Show("Registro Actualizado con Exito");
                        LoadDgvUsuario();
                    }
                    else
                        MessageBox.Show("Registro NO pudo ser Actualizado");
                    btnGrabar.Enabled = false;
                    btnEliminar.Enabled = false;
                    btnNuevo.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                obj_cn_login.Id = Convert.ToInt16(txtId.Text);
                if (obj_cn_login.EliminarUsuario(obj_cn_login))
                {
                    MessageBox.Show("Registro Eliminado con Exito");
                    LoadDgvUsuario();
                }
                else
                    MessageBox.Show("No se Pudo Eliminar el Registro");
                btnGrabar.Enabled = false;
                btnEliminar.Enabled = false;
                btnNuevo.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvUsuarios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var fila = e.RowIndex;
            if (fila > 0)
            {
                txtId.Text = dgvUsuarios.Rows[fila].Cells["ID"].Value.ToString();
                txtUsuario.Text = dgvUsuarios.Rows[fila].Cells["NOMBRE_USUARIO"].Value.ToString();
                txtContraseña.Text = dgvUsuarios.Rows[fila].Cells["CONTRASEÑA"].Value.ToString();

                btnNuevo.Enabled = false;
                btnGrabar.Enabled = true;
                btnEliminar.Enabled = true;
            }
        }

        private void frmUsuario_Load(object sender, EventArgs e)
        {
            LoadDgvUsuario();
        }
    }
}
