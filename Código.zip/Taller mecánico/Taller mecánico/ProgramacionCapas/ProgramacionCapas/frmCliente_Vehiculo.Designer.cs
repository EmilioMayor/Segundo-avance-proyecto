﻿namespace CapaPresentacion
{
    partial class frmCliente_Vehiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gbClientes = new GroupBox();
            txtCorreos = new TextBox();
            label7 = new Label();
            txtId = new TextBox();
            txtCelular = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtApellidos = new TextBox();
            label4 = new Label();
            txtCedula = new TextBox();
            label5 = new Label();
            txtNombres = new TextBox();
            label6 = new Label();
            gbVehiculo = new GroupBox();
            txtColor = new TextBox();
            lblColor = new Label();
            txtModelo = new TextBox();
            lblModelo = new Label();
            txtMarca = new TextBox();
            lblMarca = new Label();
            txtPlaca = new TextBox();
            lblPlaca = new Label();
            groupBox1 = new GroupBox();
            btnSeleccionar = new Button();
            btnEliminar = new Button();
            btnNuevo = new Button();
            btnGrabar = new Button();
            dgvClienteVehiculo = new DataGridView();
            gbClientes.SuspendLayout();
            gbVehiculo.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvClienteVehiculo).BeginInit();
            SuspendLayout();
            // 
            // gbClientes
            // 
            gbClientes.Controls.Add(txtCorreos);
            gbClientes.Controls.Add(label7);
            gbClientes.Controls.Add(txtId);
            gbClientes.Controls.Add(txtCelular);
            gbClientes.Controls.Add(label2);
            gbClientes.Controls.Add(label3);
            gbClientes.Controls.Add(txtApellidos);
            gbClientes.Controls.Add(label4);
            gbClientes.Controls.Add(txtCedula);
            gbClientes.Controls.Add(label5);
            gbClientes.Controls.Add(txtNombres);
            gbClientes.Controls.Add(label6);
            gbClientes.Controls.Add(gbVehiculo);
            gbClientes.Location = new Point(17, 15);
            gbClientes.Name = "gbClientes";
            gbClientes.Size = new Size(652, 215);
            gbClientes.TabIndex = 0;
            gbClientes.TabStop = false;
            gbClientes.Text = "Datos del cliente";
            // 
            // txtCorreos
            // 
            txtCorreos.Location = new Point(101, 107);
            txtCorreos.Margin = new Padding(4, 3, 4, 3);
            txtCorreos.Name = "txtCorreos";
            txtCorreos.Size = new Size(302, 23);
            txtCorreos.TabIndex = 42;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(24, 110);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(53, 15);
            label7.TabIndex = 41;
            label7.Text = "Corrreo: ";
            // 
            // txtId
            // 
            txtId.Location = new Point(101, 21);
            txtId.Margin = new Padding(2);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(90, 23);
            txtId.TabIndex = 40;
            // 
            // txtCelular
            // 
            txtCelular.Location = new Point(483, 77);
            txtCelular.Margin = new Padding(4, 3, 4, 3);
            txtCelular.Name = "txtCelular";
            txtCelular.Size = new Size(162, 23);
            txtCelular.TabIndex = 38;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 24);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(20, 15);
            label2.TabIndex = 39;
            label2.Text = "Id:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(425, 80);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(50, 15);
            label3.TabIndex = 37;
            label3.Text = "Celular: ";
            // 
            // txtApellidos
            // 
            txtApellidos.Location = new Point(101, 77);
            txtApellidos.Margin = new Padding(4, 3, 4, 3);
            txtApellidos.Name = "txtApellidos";
            txtApellidos.Size = new Size(302, 23);
            txtApellidos.TabIndex = 36;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 80);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(62, 15);
            label4.TabIndex = 35;
            label4.Text = "Apellidos: ";
            // 
            // txtCedula
            // 
            txtCedula.Location = new Point(483, 48);
            txtCedula.Margin = new Padding(4, 3, 4, 3);
            txtCedula.Name = "txtCedula";
            txtCedula.Size = new Size(162, 23);
            txtCedula.TabIndex = 34;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(425, 52);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(50, 15);
            label5.TabIndex = 33;
            label5.Text = "Cedula: ";
            // 
            // txtNombres
            // 
            txtNombres.Location = new Point(101, 48);
            txtNombres.Margin = new Padding(4, 3, 4, 3);
            txtNombres.Name = "txtNombres";
            txtNombres.Size = new Size(302, 23);
            txtNombres.TabIndex = 32;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(24, 52);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(62, 15);
            label6.TabIndex = 31;
            label6.Text = "Nombres: ";
            // 
            // gbVehiculo
            // 
            gbVehiculo.Controls.Add(txtColor);
            gbVehiculo.Controls.Add(lblColor);
            gbVehiculo.Controls.Add(txtModelo);
            gbVehiculo.Controls.Add(lblModelo);
            gbVehiculo.Controls.Add(txtMarca);
            gbVehiculo.Controls.Add(lblMarca);
            gbVehiculo.Controls.Add(txtPlaca);
            gbVehiculo.Controls.Add(lblPlaca);
            gbVehiculo.Location = new Point(31, 143);
            gbVehiculo.Margin = new Padding(4, 3, 4, 3);
            gbVehiculo.Name = "gbVehiculo";
            gbVehiculo.Padding = new Padding(4, 3, 4, 3);
            gbVehiculo.Size = new Size(614, 61);
            gbVehiculo.TabIndex = 25;
            gbVehiculo.TabStop = false;
            gbVehiculo.Text = "Datos de su vehiculo";
            // 
            // txtColor
            // 
            txtColor.Location = new Point(506, 23);
            txtColor.Margin = new Padding(4, 3, 4, 3);
            txtColor.Name = "txtColor";
            txtColor.Size = new Size(100, 23);
            txtColor.TabIndex = 25;
            // 
            // lblColor
            // 
            lblColor.AutoSize = true;
            lblColor.Location = new Point(470, 26);
            lblColor.Margin = new Padding(4, 0, 4, 0);
            lblColor.Name = "lblColor";
            lblColor.Size = new Size(39, 15);
            lblColor.TabIndex = 24;
            lblColor.Text = "Color:";
            // 
            // txtModelo
            // 
            txtModelo.Location = new Point(356, 23);
            txtModelo.Margin = new Padding(4, 3, 4, 3);
            txtModelo.Name = "txtModelo";
            txtModelo.Size = new Size(99, 23);
            txtModelo.TabIndex = 23;
            // 
            // lblModelo
            // 
            lblModelo.AutoSize = true;
            lblModelo.Location = new Point(306, 26);
            lblModelo.Margin = new Padding(4, 0, 4, 0);
            lblModelo.Name = "lblModelo";
            lblModelo.Size = new Size(51, 15);
            lblModelo.TabIndex = 22;
            lblModelo.Text = "Modelo:";
            // 
            // txtMarca
            // 
            txtMarca.Location = new Point(189, 23);
            txtMarca.Margin = new Padding(4, 3, 4, 3);
            txtMarca.Name = "txtMarca";
            txtMarca.Size = new Size(102, 23);
            txtMarca.TabIndex = 21;
            // 
            // lblMarca
            // 
            lblMarca.AutoSize = true;
            lblMarca.Location = new Point(149, 26);
            lblMarca.Margin = new Padding(4, 0, 4, 0);
            lblMarca.Name = "lblMarca";
            lblMarca.Size = new Size(46, 15);
            lblMarca.TabIndex = 20;
            lblMarca.Text = "Marca: ";
            // 
            // txtPlaca
            // 
            txtPlaca.Location = new Point(53, 23);
            txtPlaca.Margin = new Padding(4, 3, 4, 3);
            txtPlaca.Name = "txtPlaca";
            txtPlaca.Size = new Size(80, 23);
            txtPlaca.TabIndex = 19;
            // 
            // lblPlaca
            // 
            lblPlaca.AutoSize = true;
            lblPlaca.Location = new Point(16, 26);
            lblPlaca.Margin = new Padding(4, 0, 4, 0);
            lblPlaca.Name = "lblPlaca";
            lblPlaca.Size = new Size(41, 15);
            lblPlaca.TabIndex = 18;
            lblPlaca.Text = "Placa: ";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnSeleccionar);
            groupBox1.Controls.Add(btnEliminar);
            groupBox1.Controls.Add(btnNuevo);
            groupBox1.Controls.Add(btnGrabar);
            groupBox1.Location = new Point(675, 15);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(113, 215);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            // 
            // btnSeleccionar
            // 
            btnSeleccionar.Location = new Point(16, 169);
            btnSeleccionar.Name = "btnSeleccionar";
            btnSeleccionar.Size = new Size(92, 23);
            btnSeleccionar.TabIndex = 31;
            btnSeleccionar.Text = "Seleccionar";
            btnSeleccionar.UseVisualStyleBackColor = true;
            btnSeleccionar.Click += btnSeleccionar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Enabled = false;
            btnEliminar.Location = new Point(16, 122);
            btnEliminar.Margin = new Padding(2);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(92, 23);
            btnEliminar.TabIndex = 30;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnNuevo
            // 
            btnNuevo.Location = new Point(16, 35);
            btnNuevo.Margin = new Padding(2);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new Size(92, 23);
            btnNuevo.TabIndex = 28;
            btnNuevo.Text = "Nuevo";
            btnNuevo.UseVisualStyleBackColor = true;
            btnNuevo.Click += btnNuevo_Click;
            // 
            // btnGrabar
            // 
            btnGrabar.Enabled = false;
            btnGrabar.Location = new Point(16, 77);
            btnGrabar.Margin = new Padding(2);
            btnGrabar.Name = "btnGrabar";
            btnGrabar.Size = new Size(92, 23);
            btnGrabar.TabIndex = 29;
            btnGrabar.Text = "Grabar";
            btnGrabar.UseVisualStyleBackColor = true;
            btnGrabar.Click += btnGrabar_Click;
            // 
            // dgvClienteVehiculo
            // 
            dgvClienteVehiculo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvClienteVehiculo.Location = new Point(17, 236);
            dgvClienteVehiculo.Name = "dgvClienteVehiculo";
            dgvClienteVehiculo.RowTemplate.Height = 25;
            dgvClienteVehiculo.Size = new Size(771, 261);
            dgvClienteVehiculo.TabIndex = 2;
            dgvClienteVehiculo.CellClick += dgvClienteVehiculo_CellClick;
            // 
            // frmCliente_Vehiculo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 509);
            Controls.Add(dgvClienteVehiculo);
            Controls.Add(groupBox1);
            Controls.Add(gbClientes);
            Name = "frmCliente_Vehiculo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmCliente_Vehiculo";
            Load += frmCliente_Vehiculo_Load;
            gbClientes.ResumeLayout(false);
            gbClientes.PerformLayout();
            gbVehiculo.ResumeLayout(false);
            gbVehiculo.PerformLayout();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvClienteVehiculo).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox gbClientes;
        private GroupBox gbVehiculo;
        private TextBox txtColor;
        private Label lblColor;
        private TextBox txtModelo;
        private Label lblModelo;
        private TextBox txtMarca;
        private Label lblMarca;
        private TextBox txtPlaca;
        private Label lblPlaca;
        private GroupBox groupBox1;
        private Button btnEliminar;
        private Button btnGrabar;
        private Button btnNuevo;
        private TextBox txtId;
        private TextBox txtCelular;
        private Label label2;
        private Label label3;
        private TextBox txtApellidos;
        private Label label4;
        private TextBox txtCedula;
        private Label label5;
        private TextBox txtNombres;
        private Label label6;
        private TextBox txtCorreos;
        private Label label7;
        private DataGridView dgvClienteVehiculo;
        private Button btnSeleccionar;
    }
}