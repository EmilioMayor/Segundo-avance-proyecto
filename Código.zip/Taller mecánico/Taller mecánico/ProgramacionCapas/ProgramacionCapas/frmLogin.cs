﻿using CapaDatos.ConexionDB;
using CapaNegocio.LN_Entidades;
using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmLogin : Form
    {
        CN_Login obj_cn_login = new CN_Login();


        public frmLogin()
        {
            InitializeComponent();
        }

        private void setearControles()
        {
            txtUsuario.Text = string.Empty;
            txtContraseña.Text = string.Empty;
        }
        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            try
            {
                CN_Login CN_Login = new CN_Login();
                CN_Login.Nombre_usuario = txtUsuario.Text;
                CN_Login.Contraseña = txtContraseña.Text;

                if (CN_Login.ValidarCredenciales())
                {
                    MessageBox.Show("Inicio de sesión exitoso.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    frmPrincipal frmPrincipal = new frmPrincipal();
                    frmPrincipal.Show();
                    this.Hide();
                }
                else
                {
                    // Inicio de sesión fallido, mostrar mensaje de error
                    MessageBox.Show("Inicio de sesión fallido.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
    }
   

        private void txtContraseña_TextChanged(object sender, EventArgs e)
        {
            txtContraseña.UseSystemPasswordChar = true;

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmUsuario frmUsuario = new frmUsuario();
            frmUsuario.Show();
        }
      
        private void chbMostrar_CheckedChanged(object sender, EventArgs e)
        {
            txtContraseña.UseSystemPasswordChar = !chbMostrar.Checked;
        }
    }
}
