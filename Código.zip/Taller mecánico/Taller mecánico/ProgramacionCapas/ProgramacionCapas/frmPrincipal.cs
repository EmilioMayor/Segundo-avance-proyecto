﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void integrantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIntegrantes frmIntegrantes = new frmIntegrantes();
            frmIntegrantes.Show();
        }

        private void mantenimientoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void clienteYVehiculoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCliente_Vehiculo frmCliente_Vehiculo = new frmCliente_Vehiculo();
            frmCliente_Vehiculo.Show();
        }

        private void mecanicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMecanico frmMecanico = new frmMecanico();
            frmMecanico.Show();
        }

        private void registroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMantenimiento frmMantenimiento = new frmMantenimiento();
            frmMantenimiento.Show();
        }

    }
}
